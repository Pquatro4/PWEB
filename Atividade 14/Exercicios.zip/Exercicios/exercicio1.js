
console.log("Primeiro exemplo");